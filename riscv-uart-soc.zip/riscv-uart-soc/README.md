# RISC-V UART SoC

A memory-mapped UART peripheral integrated into a custom 5-stage pipelined RISC-V core via a bus interconnect, in SystemVerilog. Verified end-to-end (start bit through stop bit) on both Icarus Verilog and Cadence Xcelium.

## Overview

This project extends a previously built 5-stage pipelined RISC-V core (with full data-hazard forwarding and control-hazard handling) into a small System-on-Chip. The core's data memory access is routed through an address-decoded interconnect that transparently redirects memory-mapped I/O requests to either data memory or a UART transmitter, so software can send serial data using plain `sw`/`lw` instructions.

```
risc_v_core --data bus--> memory_map_unit ---> data_mem
                                          \---> uart_tx --> tx pin
```

## Address map

| Address | Destination | Access | Description |
|---|---|---|---|
| `0x0000` – `0x063F` | `data_mem` | Read/Write | General-purpose data memory |
| `0x0640` | `uart_tx` data register | Write-only | Writing a byte here starts a UART transmission (if idle) |
| `0x0644` | `uart_tx` status register | Read-only | Bit 0 = 1 while UART is transmitting |

## Modules

**`rtl/`**
- `risc_v_core.sv` — 5-stage pipelined RISC-V core; exposes a data bus (`dbus_addr`, `dbus_wdata`, `dbus_we`, `dbus_rdata`) instead of driving memory directly
- `memory_map_unit.sv` — address decoder / interconnect between the core and its two slaves
- `data_mem.sv` — general-purpose data memory
- `inst_mem.sv` — instruction memory (asynchronous read, program initialized in-file)
- `uart_tx.sv` — UART transmitter (4-state FSM, configurable clock/baud rate, LSB-first 8N1 framing)
- `soc_top.sv` — top-level integration
- Pipeline stage registers, ALU, control unit, hazard detection, and forwarding logic

**`tb/`**
- `uart_tx_tb.sv` — standalone UART frame/timing verification
- `memory_map_unit_tb.sv` — address routing and read/write path verification
- `risc_v_core_tb.sv` — core-level regression (hazards, forwarding, ISA correctness)
- `soc_top_tb.sv` — end-to-end test: loads a program, stores a byte to the UART, and checks the transmitted frame bit-by-bit against the expected value

## Running the tests

**Icarus Verilog**
```bash
iverilog -g2012 -o sim.out \
  rtl/pipeline_register.sv rtl/program_counter.sv rtl/inst_mem.sv rtl/IF_ID_Stage.sv \
  rtl/reg_file.sv rtl/imm_gen.sv rtl/control_unit.sv rtl/ID_EX_Stage.sv \
  rtl/hazard_detection.sv rtl/fwd_logic.sv rtl/alu_logic.sv rtl/branch_comp.sv \
  rtl/EX_MEM_Stage.sv rtl/data_mem.sv rtl/MEM_WB_Stage.sv rtl/risc_v_core.sv \
  rtl/uart_tx.sv rtl/memory_map_unit.sv rtl/soc_top.sv tb/soc_top_tb.sv
vvp sim.out
```

**Cadence Xcelium**
```bash
xrun -sv -timescale 1ns/1ps \
  rtl/pipeline_register.sv rtl/program_counter.sv rtl/inst_mem.sv rtl/IF_ID_Stage.sv \
  rtl/reg_file.sv rtl/imm_gen.sv rtl/control_unit.sv rtl/ID_EX_Stage.sv \
  rtl/hazard_detection.sv rtl/fwd_logic.sv rtl/alu_logic.sv rtl/branch_comp.sv \
  rtl/EX_MEM_Stage.sv rtl/data_mem.sv rtl/MEM_WB_Stage.sv rtl/risc_v_core.sv \
  rtl/uart_tx.sv rtl/memory_map_unit.sv rtl/soc_top.sv tb/soc_top_tb.sv
```

Expected output:
```
TX start bit detected, checking frame...
ALL TESTS PASSED - byte 0x41 correctly transmitted via UART
```

## A note on cross-simulator verification

During bring-up, the design passed cleanly on Icarus Verilog but consistently failed on Xcelium. Waveform tracing showed the very first instruction fetched immediately after reset release was being lost — a simulator-specific difference in event scheduling at the reset/clock boundary, not a functional bug in the core. The fix was to lead the test program with a few throwaway `NOP` instructions, so a lost fetch at that boundary costs nothing. The design now passes identically on both simulators.

## Status

Part of an ongoing RISC-V core development effort: single-cycle → 5-stage pipeline with hazard handling → this SoC integration → (in progress) privileged execution modes, ahead of use as a master core in a larger multi-core AXI4-Lite SoC.
