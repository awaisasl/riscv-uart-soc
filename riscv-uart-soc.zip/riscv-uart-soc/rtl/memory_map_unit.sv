module memory_map_unit (

    input  logic [31:0] core_addr,
    input  logic [31:0] core_wdata,
    input  logic        core_we,
    output logic [31:0] core_rdata,

    output logic [31:0] dmem_addr,
    output logic [31:0] dmem_wdata,
    output logic        dmem_we,
    input  logic [31:0] dmem_rdata,

    output logic        uart_tx_start,
    output logic [7:0]  uart_tx_data,
    input  logic        uart_busy
);

    localparam logic [31:0] UART_DATA_ADDR   = 32'h0000_0640;
    localparam logic [31:0] UART_STATUS_ADDR = 32'h0000_0644;

    wire sel_uart_data   = (core_addr == UART_DATA_ADDR);
    wire sel_uart_status = (core_addr == UART_STATUS_ADDR);

    assign dmem_addr  = core_addr;
    assign dmem_wdata = core_wdata;
    assign dmem_we    = core_we && !sel_uart_data && !sel_uart_status;

    assign uart_tx_start = core_we && sel_uart_data && !uart_busy;
    assign uart_tx_data  = core_wdata[7:0];

    always_comb begin
        if (sel_uart_status)
            core_rdata = {31'b0, uart_busy};
        else
            core_rdata = dmem_rdata;
    end

endmodule
