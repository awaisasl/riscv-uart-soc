module EX_MEM_Stage (
    input  logic        CLK,
    input  logic        rst,

    input  logic [31:0] EX_ALUResult,
    input  logic [31:0] EX_execResult,
    input  logic [31:0] EX_storeValue,
    input  logic [4:0]  EX_rs2,
    input  logic [4:0]  EX_rd,
    input  logic [2:0]  EX_funct3,
    input  logic        EX_MemRead,
    input  logic        EX_MemWrite,
    input  logic        EX_RegWrite,
    input  logic        EX_MemtoReg,

    output logic [31:0] MEM_ALUResult,
    output logic [31:0] MEM_execResult,
    output logic [31:0] MEM_storeValue,
    output logic [4:0]  MEM_rs2,
    output logic [4:0]  MEM_rd,
    output logic [2:0]  MEM_funct3,
    output logic        MEM_MemRead,
    output logic        MEM_MemWrite,
    output logic        MEM_RegWrite,
    output logic        MEM_MemtoReg
);
    pipeline_register #(.WIDTH(32)) r_alu      (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(EX_ALUResult),  .data_out(MEM_ALUResult));
    pipeline_register #(.WIDTH(32)) r_exec     (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(EX_execResult), .data_out(MEM_execResult));
    pipeline_register #(.WIDTH(32)) r_store    (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(EX_storeValue), .data_out(MEM_storeValue));
    pipeline_register #(.WIDTH(5))  r_rs2      (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(EX_rs2),        .data_out(MEM_rs2));
    pipeline_register #(.WIDTH(5))  r_rd       (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(EX_rd),         .data_out(MEM_rd));
    pipeline_register #(.WIDTH(3))  r_funct3   (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(EX_funct3),     .data_out(MEM_funct3));
    pipeline_register #(.WIDTH(1))  r_memread  (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(EX_MemRead),    .data_out(MEM_MemRead));
    pipeline_register #(.WIDTH(1))  r_memwrite (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(EX_MemWrite),   .data_out(MEM_MemWrite));
    pipeline_register #(.WIDTH(1))  r_regwrite (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(EX_RegWrite),   .data_out(MEM_RegWrite));
    pipeline_register #(.WIDTH(1))  r_m2r      (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(EX_MemtoReg),   .data_out(MEM_MemtoReg));
endmodule
