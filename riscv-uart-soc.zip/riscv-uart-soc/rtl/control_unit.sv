module control_unit (
    input  logic [6:0] opcode,
    input  logic [2:0] funct3,
    input  logic [6:0] funct7,
    output logic       ALUSrc,
    output logic       MemtoReg,
    output logic       RegWrite,
    output logic       MemRead,
    output logic       MemWrite,
    output logic       Branch,
    output logic       Jump,
    output logic       Jalr,
    output logic       LUI,
    output logic       AUIPC,
    output logic [3:0] ALUControl
);
    always_comb begin
        ALUSrc     = 1'b0;
        MemtoReg   = 1'b0;
        RegWrite   = 1'b0;
        MemRead    = 1'b0;
        MemWrite   = 1'b0;
        Branch     = 1'b0;
        Jump       = 1'b0;
        Jalr       = 1'b0;
        LUI        = 1'b0;
        AUIPC      = 1'b0;
        ALUControl = 4'b0010;

        case (opcode)

            7'b0110011: begin
                RegWrite = 1'b1;
                case (funct3)
                    3'b000: ALUControl = funct7[5] ? 4'b0110 : 4'b0010;
                    3'b001: ALUControl = 4'b0100;
                    3'b010: ALUControl = 4'b0101;
                    3'b011: ALUControl = 4'b0111;
                    3'b100: ALUControl = 4'b0011;
                    3'b101: ALUControl = funct7[5] ? 4'b1001 : 4'b1000;
                    3'b110: ALUControl = 4'b0001;
                    3'b111: ALUControl = 4'b0000;
                    default: ALUControl = 4'b0010;
                endcase
            end

            7'b0010011: begin
                ALUSrc   = 1'b1;
                RegWrite = 1'b1;
                case (funct3)
                    3'b000: ALUControl = 4'b0010;
                    3'b001: ALUControl = 4'b0100;
                    3'b010: ALUControl = 4'b0101;
                    3'b011: ALUControl = 4'b0111;
                    3'b100: ALUControl = 4'b0011;
                    3'b101: ALUControl = funct7[5] ? 4'b1001 : 4'b1000;
                    3'b110: ALUControl = 4'b0001;
                    3'b111: ALUControl = 4'b0000;
                    default: ALUControl = 4'b0010;
                endcase
            end

            7'b0000011: begin
                ALUSrc     = 1'b1;
                MemtoReg   = 1'b1;
                RegWrite   = 1'b1;
                MemRead    = 1'b1;
                ALUControl = 4'b0010;
            end

            7'b0100011: begin
                ALUSrc     = 1'b1;
                MemWrite   = 1'b1;
                ALUControl = 4'b0010;
            end

            7'b1100011: begin
                Branch = 1'b1;
            end

            7'b1101111: begin
                RegWrite = 1'b1;
                Jump     = 1'b1;
            end

            7'b1100111: begin
                ALUSrc     = 1'b1;
                RegWrite   = 1'b1;
                Jump       = 1'b1;
                Jalr       = 1'b1;
                ALUControl = 4'b0010;
            end

            7'b0110111: begin
                RegWrite = 1'b1;
                LUI      = 1'b1;
            end

            7'b0010111: begin
                RegWrite = 1'b1;
                AUIPC    = 1'b1;
            end

            default: begin

            end
        endcase
    end
endmodule
