module alu_logic (
    input  logic [31:0] A,
    input  logic [31:0] B,
    input  logic [3:0]  ALUControl,
    output logic [31:0] Result,
    output logic        Zero,
    output logic        Overflow
);
    always_comb begin
        Result   = 32'b0;
        Overflow = 1'b0;

        case (ALUControl)
            4'b0000: Result = A & B;
            4'b0001: Result = A | B;
            4'b0010: begin
                Result   = A + B;
                Overflow = (~(A[31] ^ B[31])) & (Result[31] ^ A[31]);
            end
            4'b0011: Result = A ^ B;
            4'b0100: Result = A << B[4:0];
            4'b0101: Result = ($signed(A) < $signed(B)) ? 32'd1 : 32'd0;
            4'b0110: begin
                Result   = A - B;
                Overflow = (A[31] ^ B[31]) & (Result[31] ^ A[31]);
            end
            4'b0111: Result = (A < B) ? 32'd1 : 32'd0;
            4'b1000: Result = A >> B[4:0];
            4'b1001: Result = $signed(A) >>> B[4:0];
            default: begin
                Result   = 32'b0;
                Overflow = 1'b0;
            end
        endcase
    end

    assign Zero = (Result == 32'b0);
endmodule
