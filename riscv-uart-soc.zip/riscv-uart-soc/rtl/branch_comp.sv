module branch_comp (
    input  logic [31:0] data1,
    input  logic [31:0] data2,
    input  logic [2:0]  funct3,
    output logic        branchTaken
);
    always_comb begin
        case (funct3)
            3'b000: branchTaken = (data1 == data2);
            3'b001: branchTaken = (data1 != data2);
            3'b100: branchTaken = ($signed(data1) < $signed(data2));
            3'b101: branchTaken = ($signed(data1) >= $signed(data2));
            3'b110: branchTaken = (data1 < data2);
            3'b111: branchTaken = (data1 >= data2);
            default: branchTaken = 1'b0;
        endcase
    end
endmodule
