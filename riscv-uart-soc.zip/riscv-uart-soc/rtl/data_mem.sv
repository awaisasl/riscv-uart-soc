module data_mem (
    input  logic        CLK,
    input  logic        MemWrite,
    input  logic [31:0] addr,
    input  logic [31:0] dataW,
    output logic [31:0] dataR
);
    logic [31:0] mem [0:255];

    assign dataR = mem[addr[9:2]];

    always_ff @(posedge CLK) begin
        if (MemWrite)
            mem[addr[9:2]] <= dataW;
    end
endmodule
