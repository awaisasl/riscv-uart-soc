module fwd_logic (
    input  logic [4:0] EX_rs1,
    input  logic [4:0] EX_rs2,

    input  logic [4:0] MEM_rd,
    input  logic       MEM_RegWrite,

    input  logic [4:0] WB_rd,
    input  logic       WB_RegWrite,

    input  logic [4:0] MEM_rs2,
    input  logic       MEM_MemWrite,

    output logic [1:0] fwd_A,
    output logic [1:0] fwd_B,
    output logic       fwd_store
);

    always_comb begin
        fwd_A     = 2'b00;
        fwd_B     = 2'b00;
        fwd_store = 1'b0;

        if (MEM_RegWrite && (MEM_rd != 5'd0) && (MEM_rd == EX_rs1))
            fwd_A = 2'b10;
        else if (WB_RegWrite && (WB_rd != 5'd0) && (WB_rd == EX_rs1))
            fwd_A = 2'b01;

        if (MEM_RegWrite && (MEM_rd != 5'd0) && (MEM_rd == EX_rs2))
            fwd_B = 2'b10;
        else if (WB_RegWrite && (WB_rd != 5'd0) && (WB_rd == EX_rs2))
            fwd_B = 2'b01;

        if (MEM_MemWrite && WB_RegWrite && (WB_rd != 5'd0) && (WB_rd == MEM_rs2))
            fwd_store = 1'b1;
    end
endmodule
