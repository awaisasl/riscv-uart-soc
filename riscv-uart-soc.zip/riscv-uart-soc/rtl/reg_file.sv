module reg_file (
    input  logic        CLK,
    input  logic        RegWEn,
    input  logic [4:0]  rs1,
    input  logic [4:0]  rs2,
    input  logic [4:0]  rd,
    input  logic [31:0] dataW,
    output logic [31:0] data1,
    output logic [31:0] data2
);
    logic [31:0] registers [0:31];

    assign data1 = (rs1 == 5'd0) ? 32'b0 : registers[rs1];
    assign data2 = (rs2 == 5'd0) ? 32'b0 : registers[rs2];

    always_ff @(posedge CLK) begin
        if (RegWEn && (rd != 5'd0))
            registers[rd] <= dataW;
    end
endmodule
