module inst_mem (
    input  logic [31:0] addr,
    output logic [31:0] instruction
);

    (* rom_style = "distributed" *)
    logic [31:0] mem [0:255];

    initial begin

        mem[0]  = 32'h00000013;
        mem[1]  = 32'h00000013;
        mem[2]  = 32'h00000013;

        mem[3]  = 32'h04100093;

        mem[4]  = 32'h00000013;
        mem[5]  = 32'h00000013;
        mem[6]  = 32'h00000013;
        mem[7]  = 32'h00000013;
        mem[8]  = 32'h00000013;
        mem[9]  = 32'h00000013;

        mem[10] = 32'h64102023;

        mem[11] = 32'h64402103;

        mem[12] = 32'h00117193;

        mem[13] = 32'hFE019CE3;

        mem[14] = 32'h0000006F;
    end

    assign instruction = mem[addr[9:2]];

endmodule
