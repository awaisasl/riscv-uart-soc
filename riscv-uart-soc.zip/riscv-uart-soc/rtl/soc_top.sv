module soc_top (
    input  logic clk,
    input  logic rst,
    output logic tx
);

    logic [31:0] core_addr;
    logic [31:0] core_wdata;
    logic        core_we;
    logic [31:0] core_rdata;

    logic [31:0] dmem_addr;
    logic [31:0] dmem_wdata;
    logic        dmem_we;
    logic [31:0] dmem_rdata;

    logic        uart_tx_start;
    logic [7:0]  uart_tx_data;
    logic        uart_busy;

    risc_v_core core_inst (
        .CLK        (clk),
        .rst        (rst),
        .dbus_addr  (core_addr),
        .dbus_wdata (core_wdata),
        .dbus_we    (core_we),
        .dbus_rdata (core_rdata)
    );

    memory_map_unit mmu_inst (
        .core_addr     (core_addr),
        .core_wdata    (core_wdata),
        .core_we       (core_we),
        .core_rdata    (core_rdata),

        .dmem_addr     (dmem_addr),
        .dmem_wdata    (dmem_wdata),
        .dmem_we       (dmem_we),
        .dmem_rdata    (dmem_rdata),

        .uart_tx_start (uart_tx_start),
        .uart_tx_data  (uart_tx_data),
        .uart_busy     (uart_busy)
    );

    data_mem data_memory_inst (
        .CLK      (clk),
        .MemWrite (dmem_we),
        .addr     (dmem_addr),
        .dataW    (dmem_wdata),
        .dataR    (dmem_rdata)
    );

    uart_tx #(
        .CLK_FREQ  (100_000_000),
        .BAUD_RATE (9600)
    ) uart_tx_inst (
        .clk      (clk),
        .rst      (rst),
        .tx_start (uart_tx_start),
        .tx_data  (uart_tx_data),
        .tx       (tx),
        .busy     (uart_busy)
    );

endmodule
