module MEM_WB_Stage (
    input  logic        CLK,
    input  logic        rst,
    input  logic [31:0] MEM_loadData,
    input  logic [31:0] MEM_execResult,
    input  logic [4:0]  MEM_rd,
    input  logic        MEM_RegWrite,
    input  logic        MEM_MemtoReg,
    output logic [31:0] WB_loadData,
    output logic [31:0] WB_execResult,
    output logic [4:0]  WB_rd,
    output logic        WB_RegWrite,
    output logic        WB_MemtoReg
);
    pipeline_register #(.WIDTH(32)) r_load     (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(MEM_loadData),   .data_out(WB_loadData));
    pipeline_register #(.WIDTH(32)) r_exec     (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(MEM_execResult), .data_out(WB_execResult));
    pipeline_register #(.WIDTH(5))  r_rd       (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(MEM_rd),         .data_out(WB_rd));
    pipeline_register #(.WIDTH(1))  r_regwrite (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(MEM_RegWrite),   .data_out(WB_RegWrite));
    pipeline_register #(.WIDTH(1))  r_m2r      (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(MEM_MemtoReg),   .data_out(WB_MemtoReg));
endmodule
