`timescale 1ns/1ps

module risc_v_core_tb;
    logic CLK;
    logic rst;

    logic [31:0] dbus_addr;
    logic [31:0] dbus_wdata;
    logic        dbus_we;
    logic [31:0] dbus_rdata;
    logic [31:0] mem [0:255];

    assign dbus_rdata = mem[dbus_addr[9:2]];

    always_ff @(posedge CLK) begin
        if (dbus_we)
            mem[dbus_addr[9:2]] <= dbus_wdata;
    end

    risc_v_core dut (
        .CLK(CLK),
        .rst(rst),
        .dbus_addr(dbus_addr),
        .dbus_wdata(dbus_wdata),
        .dbus_we(dbus_we),
        .dbus_rdata(dbus_rdata)
    );

    initial begin
        CLK = 1'b0;
        forever #5 CLK = ~CLK;
    end

    function automatic [31:0] enc_R(
        input [6:0] funct7,
        input [4:0] rs2,
        input [4:0] rs1,
        input [2:0] funct3,
        input [4:0] rd,
        input [6:0] opcode
    );
        enc_R = {funct7, rs2, rs1, funct3, rd, opcode};
    endfunction

    function automatic [31:0] enc_I(
        input [11:0] imm,
        input [4:0]  rs1,
        input [2:0]  funct3,
        input [4:0]  rd,
        input [6:0]  opcode
    );
        enc_I = {imm, rs1, funct3, rd, opcode};
    endfunction

    function automatic [31:0] enc_S(
        input [11:0] imm,
        input [4:0]  rs2,
        input [4:0]  rs1,
        input [2:0]  funct3,
        input [6:0]  opcode
    );
        enc_S = {imm[11:5], rs2, rs1, funct3, imm[4:0], opcode};
    endfunction

    function automatic [31:0] enc_B(
        input [12:0] imm,
        input [4:0]  rs2,
        input [4:0]  rs1,
        input [2:0]  funct3
    );
        enc_B = {imm[12], imm[10:5], rs2, rs1, funct3,
                 imm[4:1], imm[11], 7'b1100011};
    endfunction

    function automatic [31:0] enc_U(
        input [19:0] imm20,
        input [4:0]  rd,
        input [6:0]  opcode
    );
        enc_U = {imm20, rd, opcode};
    endfunction

    localparam [31:0] NOP = 32'h00000013;

    integer i;
    integer errors;

    task automatic check_reg(
        input integer reg_index,
        input [31:0] expected
    );
        begin
            if (dut.register_file.registers[reg_index] !== expected) begin
                $display("FAIL: x%0d = %h, expected %h",
                         reg_index,
                         dut.register_file.registers[reg_index],
                         expected);
                errors = errors + 1;
            end
            else begin
                $display("PASS: x%0d = %h", reg_index, expected);
            end
        end
    endtask

    task automatic check_mem_word(
        input integer word_index,
        input [31:0] expected
    );
        begin
            if (mem[word_index] !== expected) begin
                $display("FAIL: mem[%0d] = %h, expected %h",
                         word_index,
                         mem[word_index],
                         expected);
                errors = errors + 1;
            end
            else begin
                $display("PASS: mem[%0d] = %h", word_index, expected);
            end
        end
    endtask

    initial begin
        errors = 0;
        rst    = 1'b1;

        for (i = 0; i < 256; i = i + 1) begin
            dut.instruction_memory.mem[i] = NOP;
            mem[i]        = 32'b0;
        end

        for (i = 0; i < 32; i = i + 1)
            dut.register_file.registers[i] = 32'b0;

        dut.register_file.registers[10] = 32'd100;
        dut.register_file.registers[11] = 32'd24;

        dut.instruction_memory.mem[0] = enc_I(12'd5, 5'd0, 3'b000, 5'd1, 7'b0010011);

        dut.instruction_memory.mem[1] = enc_I(12'd7, 5'd0, 3'b000, 5'd2, 7'b0010011);

        dut.instruction_memory.mem[2] = enc_R(7'b0000000, 5'd2, 5'd1, 3'b000, 5'd3, 7'b0110011);

        dut.instruction_memory.mem[3] = enc_R(7'b0000000, 5'd2, 5'd3, 3'b000, 5'd4, 7'b0110011);

        dut.instruction_memory.mem[4] = enc_S(12'd0, 5'd4, 5'd10, 3'b010, 7'b0100011);

        dut.instruction_memory.mem[5] = enc_I(12'd0, 5'd10, 3'b010, 5'd5, 7'b0000011);

        dut.instruction_memory.mem[6] = enc_R(7'b0000000, 5'd1, 5'd5, 3'b000, 5'd6, 7'b0110011);

        dut.instruction_memory.mem[7] = enc_B(13'd12, 5'd11, 5'd6, 3'b000);

        dut.instruction_memory.mem[8] = enc_I(12'd99, 5'd0, 3'b000, 5'd7, 7'b0010011);
        dut.instruction_memory.mem[9] = enc_I(12'd88, 5'd0, 3'b000, 5'd8, 7'b0010011);

        dut.instruction_memory.mem[10] = enc_I(12'd7, 5'd0, 3'b000, 5'd7, 7'b0010011);

        dut.instruction_memory.mem[11] = enc_I(12'd1, 5'd0, 3'b000, 5'd8, 7'b0010011);

        dut.instruction_memory.mem[12] = enc_B(13'd8, 5'd0, 5'd8, 3'b000);

        dut.instruction_memory.mem[13] = enc_I(12'd9, 5'd0, 3'b000, 5'd9, 7'b0010011);

        dut.instruction_memory.mem[14] = enc_I(12'd0, 5'd10, 3'b010, 5'd12, 7'b0000011);

        dut.instruction_memory.mem[15] = enc_B(13'd12, 5'd4, 5'd12, 3'b000);

        dut.instruction_memory.mem[16] = enc_I(12'd99, 5'd0, 3'b000, 5'd13, 7'b0010011);
        dut.instruction_memory.mem[17] = enc_I(12'd88, 5'd0, 3'b000, 5'd14, 7'b0010011);

        dut.instruction_memory.mem[18] = enc_I(12'd13, 5'd0, 3'b000, 5'd13, 7'b0010011);

        dut.instruction_memory.mem[19] = enc_I(12'd0, 5'd10, 3'b010, 5'd15, 7'b0000011);

        dut.instruction_memory.mem[20] = enc_S(12'd4, 5'd15, 5'd10, 3'b010, 7'b0100011);

        dut.instruction_memory.mem[21] = enc_I(12'd4, 5'd10, 3'b010, 5'd16, 7'b0000011);

        dut.instruction_memory.mem[22] = enc_U(20'h12345, 5'd17, 7'b0110111);

        dut.instruction_memory.mem[23] = enc_U(20'h00001, 5'd18, 7'b0010111);

        repeat (2) @(posedge CLK);
        #1 rst = 1'b0;

        repeat (100) @(posedge CLK);
        #1;

        $display("\n========================================");
        $display(" CUMULATIVE PIPELINE / HAZARD TEST");
        $display("========================================");

        check_reg(1,  32'd5);
        check_reg(2,  32'd7);
        check_reg(3,  32'd12);
        check_reg(4,  32'd19);
        check_reg(5,  32'd19);
        check_reg(6,  32'd24);
        check_reg(7,  32'd7);
        check_reg(8,  32'd1);
        check_reg(9,  32'd9);
        check_reg(12, 32'd19);
        check_reg(13, 32'd13);
        check_reg(14, 32'd0);
        check_reg(15, 32'd19);
        check_reg(16, 32'd19);
        check_reg(17, 32'h12345000);
        check_reg(18, 32'h0000105C);

        check_mem_word(25, 32'd19);
        check_mem_word(26, 32'd19);

        if (errors == 0)
            $display("\nALL TESTS PASSED");
        else
            $display("\nTEST FAILED: %0d error(s)", errors);

        $display("========================================\n");
        $finish;
    end
endmodule
