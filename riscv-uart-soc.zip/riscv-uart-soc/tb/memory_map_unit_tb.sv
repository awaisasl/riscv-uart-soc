`timescale 1ns/1ps

module memory_map_unit_tb;

    logic [31:0] core_addr;
    logic [31:0] core_wdata;
    logic        core_we;
    logic [31:0] core_rdata;

    logic [31:0] dmem_addr;
    logic [31:0] dmem_wdata;
    logic        dmem_we;
    logic [31:0] dmem_rdata;

    logic        uart_tx_start;
    logic [7:0]  uart_tx_data;
    logic        uart_busy;

    int errors = 0;

    memory_map_unit dut (
        .core_addr(core_addr), .core_wdata(core_wdata),
        .core_we(core_we),     .core_rdata(core_rdata),
        .dmem_addr(dmem_addr), .dmem_wdata(dmem_wdata),
        .dmem_we(dmem_we),      .dmem_rdata(dmem_rdata),
        .uart_tx_start(uart_tx_start), .uart_tx_data(uart_tx_data),
        .uart_busy(uart_busy)
    );

    task automatic check(input logic cond, input string msg);
        if (!cond) begin
            $display("FAIL: %s", msg);
            errors++;
        end
    endtask

    initial begin

        core_addr  = 32'h0000_0010;
        core_wdata = 32'hDEAD_BEEF;
        core_we    = 1'b1;
        uart_busy  = 1'b0;
        dmem_rdata = 32'h1234_5678;
        #10;
        check(dmem_we == 1'b1, "normal write should assert dmem_we");
        check(dmem_addr == core_addr, "normal write address should pass through");
        check(dmem_wdata == core_wdata, "normal write data should pass through");
        check(uart_tx_start == 1'b0, "normal write must not trigger uart_tx_start");

        core_we = 1'b0;
        #10;
        check(core_rdata == dmem_rdata, "normal read should return dmem_rdata");

        core_addr  = 32'h0000_0640;
        core_wdata = 32'h0000_00A5;
        core_we    = 1'b1;
        uart_busy  = 1'b0;
        #10;
        check(uart_tx_start == 1'b1, "write to 0x640 while idle should start uart tx");
        check(uart_tx_data == 8'hA5, "uart_tx_data should be lowest byte of wdata");
        check(dmem_we == 1'b0, "write to 0x640 must NOT write to data memory");

        uart_busy = 1'b1;
        #10;
        check(uart_tx_start == 1'b0, "write to 0x640 while busy must not start uart tx");

        core_we   = 1'b0;
        core_addr = 32'h0000_0644;
        uart_busy = 1'b1;
        #10;
        check(core_rdata == 32'h0000_0001, "status read while busy should return 1");

        uart_busy = 1'b0;
        #10;
        check(core_rdata == 32'h0000_0000, "status read while idle should return 0");

        if (errors == 0)
            $display("ALL TESTS PASSED");
        else
            $display("%0d TEST(S) FAILED", errors);

        $finish;
    end

endmodule
