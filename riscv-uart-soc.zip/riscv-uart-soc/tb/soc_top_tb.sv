`timescale 1ns/1ps

module soc_top_tb;

    localparam CLK_PERIOD   = 10;
    localparam CLKS_PER_BIT = 100_000_000 / 9600;

    logic clk;
    logic rst;
    logic tx;
    logic [7:0] expected_byte;

    int errors = 0;

    soc_top dut (
        .clk(clk),
        .rst(rst),
        .tx(tx)
    );

    always #(CLK_PERIOD/2) clk = ~clk;

    task automatic wait_bit_time();
        repeat (CLKS_PER_BIT) @(posedge clk);
    endtask

    initial begin

        #1;
        clk = 0;
        rst = 1;

        repeat (4) @(posedge clk);
        rst = 0;
        @(posedge clk);

        fork
            begin
                wait (tx === 1'b0);
            end
            begin
                #200000;
                if (tx !== 1'b0) begin
                    $display("FAIL: TX never started - byte was not transmitted");
                    errors++;
                end
            end
        join_any
        disable fork;

        if (tx === 1'b0) begin
            int i;
            expected_byte = 8'h41;
            $display("TX start bit detected, checking frame...");

            wait_bit_time();

            for (i = 0; i < 8; i++) begin
                @(negedge clk);
                if (tx !== expected_byte[i]) begin
                    $display("FAIL: data bit %0d mismatch (exp %b got %b)", i, expected_byte[i], tx);
                    errors++;
                end
                wait_bit_time();
            end

            @(negedge clk);
            if (tx !== 1'b1) begin
                $display("FAIL: stop bit not high");
                errors++;
            end
        end

        repeat (2000) @(posedge clk);

        if (errors == 0)
            $display("ALL TESTS PASSED - byte 0x41 correctly transmitted via UART");
        else
            $display("%0d TEST(S) FAILED", errors);

        $finish;
    end

endmodule
