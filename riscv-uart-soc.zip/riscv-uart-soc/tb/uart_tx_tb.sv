`timescale 1ns/1ps

module uart_tx_tb;

    localparam CLK_FREQ    = 100_000_000;
    localparam BAUD_RATE   = 9600;
    localparam CLKS_PER_BIT = CLK_FREQ / BAUD_RATE;
    localparam CLK_PERIOD  = 10;

    logic       clk;
    logic       rst;
    logic       tx_start;
    logic [7:0] tx_data;
    logic       tx;
    logic       busy;

    int errors = 0;

    uart_tx #(
        .CLK_FREQ(CLK_FREQ),
        .BAUD_RATE(BAUD_RATE)
    ) dut (
        .clk(clk), .rst(rst),
        .tx_start(tx_start), .tx_data(tx_data),
        .tx(tx), .busy(busy)
    );

    always #(CLK_PERIOD/2) clk = ~clk;

    task automatic wait_bit_time();
        repeat (CLKS_PER_BIT) @(posedge clk);
    endtask

    task automatic send_and_check(input [7:0] byte_to_send);
        int i;
        @(posedge clk);
        tx_start = 1'b1;
        tx_data  = byte_to_send;
        @(posedge clk);
        tx_start = 1'b0;

        @(negedge clk);
        if (tx !== 1'b0) begin
            $display("FAIL: start bit not seen for byte %0h", byte_to_send);
            errors++;
        end
        if (busy !== 1'b1) begin
            $display("FAIL: busy not asserted during start bit");
            errors++;
        end

        wait_bit_time();

        for (i = 0; i < 8; i++) begin
            @(negedge clk);
            if (tx !== byte_to_send[i]) begin
                $display("FAIL: data bit %0d mismatch for byte %0h (exp %b got %b)",
                           i, byte_to_send, byte_to_send[i], tx);
                errors++;
            end
            wait_bit_time();
        end

        @(negedge clk);
        if (tx !== 1'b1) begin
            $display("FAIL: stop bit not seen for byte %0h", byte_to_send);
            errors++;
        end
        wait_bit_time();

        @(negedge clk);
        if (busy !== 1'b0) begin
            $display("FAIL: busy did not clear after stop bit for byte %0h", byte_to_send);
            errors++;
        end
        if (tx !== 1'b1) begin
            $display("FAIL: line not idle-high after transmission");
            errors++;
        end
    endtask

    initial begin
        clk = 0;
        rst = 1;
        tx_start = 0;
        tx_data  = 8'h00;
        repeat (3) @(posedge clk);
        rst = 0;
        @(posedge clk);

        send_and_check(8'hA5);
        send_and_check(8'h00);
        send_and_check(8'hFF);
        send_and_check(8'h55);

        @(posedge clk);
        tx_start = 1'b1;
        tx_data  = 8'h11;
        @(posedge clk);
        tx_start = 1'b0;
        @(posedge clk);
        tx_start = 1'b1;
        tx_data  = 8'h22;
        @(posedge clk);
        tx_start = 1'b0;

        repeat (10 * CLKS_PER_BIT) @(posedge clk);

        if (errors == 0)
            $display("ALL TESTS PASSED");
        else
            $display("%0d TEST(S) FAILED", errors);

        $finish;
    end

endmodule
